<?php 
define('SERVER','localhost');
define('UID','root');
define('PASSWORD','password');
define('DB_NAME','sipemadam');
?>